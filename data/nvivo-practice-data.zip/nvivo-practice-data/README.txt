#SydneyRent: synthetic social media corpus on housing and renting in NSW

SYNTHETIC DATA written for teaching (NVivo HDR workshop, University of Sydney, Nov 2026). All users, posts and events are fictional. Any resemblance to real people or accounts is coincidental.

Contents
--------
posts/       19 Word files, one per user (86 posts, March-May 2026).
             Each file = one case. Posts are separated by 'Heading 2' lines.
users.xlsx   Classification sheet: one row per user (case) with Gender, Age group,
             Tenure and Location. The first column matches the file names.
all_posts.xlsx  All posts in one table (one row per post), for exploring outside NVivo.

Session 1: Import > Files > select everything in posts/ (tick "Create a case for
each imported file" if you want to save a step for Session 2).
Session 2: Import > Classification Sheets > users.xlsx (case classification).
